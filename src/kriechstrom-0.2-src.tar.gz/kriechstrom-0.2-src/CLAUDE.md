# KRIECHSTROM

Dark industrial / EBM firmware for the M-VAVE FM-1 (both flash chips, including the newer 0xB36014).
A GPL-3.0 fork of Felucca 1.8.2 (Leo Kuroshita, Hügelton Instruments), with ideas and parts taken from Glitchbox
(erikdevos). Author: Grigorii Bezborodov, GitHub `Xforsa/kriechstrom`, site `https://xforsa.github.io/kriechstrom/`.

## Hard rules

- This is a public repository. Never commit internal notes, plans, checklists, scratch files or Russian working text.
  Working notes live outside the repo in `../krst-notes/`. Before every push, scan tracked files for Cyrillic outside
  the Russian site/manual pages and the installer/editor RU strings, for personal paths and emails, for TODO files.
- This file is local only (listed in `.git/info/exclude`). Never commit it, and never mention Claude or AI in commits,
  PRs, release notes or any other git artifact: no `Co-Authored-By`, no "Generated with".
- Never use the em dash (—) anywhere. Use a hyphen, colon or comma.
- Public copy (README, release notes, site, manual, fmhub.json) is plain and factual. No marketing fluff, no jokey
  bullets, no invented feature names. Re-read it before publishing.
- Remote `felucca` is upstream Felucca with push DISABLED. Never push there, never push Felucca's tags.
  Only `origin` (Xforsa/kriechstrom) is ours.
- Force push only with the user's explicit permission, given for that specific push.
- Identity: every release is `FM-1_57810002` (0.1 was `FM-1_57810001`). It is registered on The Firmware Hub; never
  change it. Development builds are `FM-1_57810000`.

## Layout

- `firmware/src/` - the firmware. KRST additions: `krst_damage.c` (DAMAGE/CHAR/WALL/HISS master chain, the DAMG
  insert, the level keeper), `krst_dice.c` (DICE, MOOD, OOPS), `krst_art.h` (generated splash). `engines.c` holds the
  patterns and the demo project, `params.c` the pages and display names, `ui_draw.c` the splash.
- `firmware/engines/` - Felucca-Engines, kept in tree.
- `tests/` - host tests (`run_tests.sh`), KRST tests are `krst_*_test.c` and `seq155_test.c`.
- `web/` - installer (`index_pkg.html` + `fm1pkg.js` + `fm1ota.js` + `fm1backup.js`, inlined by `make_site.py`) and
  the editor (`editor.html`). Tests: `test_web.mjs`, `test_backup.mjs`.
- `site/` - landing pages (`index.html` EN default, `ru.html`), manual (`manual/en.html`, `manual/ru.html`, cheat sheet
  first), `build.py` assembles `build/site/`.
- `tools/` - `build.py` (package), `krst_release.sh`, `krst_pages.sh`, `krst_art.py` (art, favicon, splash RLE),
  `fm1_install.py` (install from the command line).
- `fmhub.json` - the Firmware Hub card. Only its allowed fields; `what` is plain English, at most 300 characters.

## Firmware conventions

- Stored formats (projects, presets, banks) are append-only. Old files must keep loading.
- Globals: `G_COUNT` is 27 and fixed. The inert Felucca slots `G_DRLVL`, `G_DRREV`, `G_ENGGO` are reused as `G_DMG`,
  `G_DMGC`, `G_WALL`. `G_HISS` is `G_COUNT` (`G_ALL` = 28), stored in the project spare byte
  `PROJ_HISS_OFF = PROJ_MIDI_OFF - 1`.
- Master chain in `fx.c` `mix_block`: wet add -> `kl_energy` -> `dmg_master` -> `wall_master` -> `krst_level` (only
  ever lowers the level) -> `hiss_master`. HISS runs only while the tape runs (song playing or a voice active).
- WALL pushes sends and DIST, but never distorts DRUM parts (it killed the kick).
- With every effect at 0 the output must stay bit-identical to Felucca (`krst_damage_test` checks it).
- Build switches `KRST_PALETTE`, `KRST_LARGE_DEF`, `KRST_PANEL_DEF`, `KRST_DEMO_DEF`; the tests build with all of
  them at 0.

## Commands

- Build: `sh build.sh` (Docker, JieLi toolchain, AC79 SDK). Release: `tools/krst_release.sh X.Y` (runs
  `build.sh --release X.Y`, makes `build/release-X.Y/` and `build/site/`).
- Tests: `sh tests/run_tests.sh` (about 10 minutes; `BUDGET_UPDATE=1` / `GOLDEN_UPDATE=1` to refresh). Engine
  goldens: `UPDATE=1 sh firmware/engines/tests/run.sh`. In zsh, word-split flag variables with `${=F}`.
- Web tests: `/opt/homebrew/opt/node/bin/node web/test_web.mjs` and `web/test_backup.mjs` (call node by full path;
  the shell's nvm hook is broken).
- Site: `python3 site/build.py build/kriechstrom-X.Y.fwsc X.Y`, then `tools/krst_pages.sh` and
  `git -C build/pages push origin gh-pages`.
- Install on the user's FM-1 (connected to this Mac): `python3 tools/fm1_install.py PKG --port Clipper --yes`.
  macOS caches the MIDI port name; on this machine it is still "Clipper".

## Releases and the Firmware Hub

- A release is a GitHub release with `kriechstrom-X.Y.fwsc` attached, notes from `docs/release-X.Y.md`, and a
  `CHANGELOG.md` entry (Keep a Changelog; collect changes under Unreleased first).
- Site-only changes (installer, editor, manual) do not need a release: rebuild the site and publish Pages.
- The hub picks up new releases by itself; card changes go through `fmhub.json` on `main`.
- Credit Felucca and Glitchbox wherever the project is described ("built on Felucca", parts from Glitchbox).

## Working with the user

- The user writes in Russian; answer in Russian, short and natural.
- For larger tasks: research and a plan first, then code.
- Everything shipped must be tested: host tests, web tests, and on the real FM-1 when the firmware changes.
