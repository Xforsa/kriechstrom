#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Build the KRIECHSTROM site into OUT (default build/site):

  index.html, ru.html, style.css     the landing pages (EN, RU)
  manual/en.html, manual/ru.html     the manual, the sound list filled in from the firmware's own tables
  shots/*.png                        the screens the pages use, from tests/ui_render (build/ui_new/LARGE_STROM)
  audio/*.m4a                        the sound demos the pages use, from tools/krst_demos.sh (build/demos)
  webapp/installer, webapp/editor    web/make_site.py
  words/*.json                       the screen reader's words files (web/words: every one ever linked; a device
                                     points at the one its build was made with, build/gen/ann_words.h)
  firmware/kriechstrom-VER.fwsc      the package
  src/kriechstrom-VER-src.tar.gz     the source of this build (GPL-3.0): the files git tracks

  python3 site/build.py build/kriechstrom-0.1.fwsc 0.1 [OUT]

The pages, the sound list and the counts come from the tree as it is: build the site from the release's commit.
"""
import re
import shutil
import subprocess
import sys
import tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT / "site"
SHOTS = ROOT / "build" / "ui_new" / "LARGE_STROM"
DEMOS = ROOT / "build" / "demos"

ENGINES = [  # (name shown, source, table, engine number in ENGINES[])
    ("ANALOG", "firmware/engines/src/eng_analog.c", "ANALOG_PRESETS", 0),
    ("FM6", "firmware/src/eng_fm6.c", "FM6_PRESETS", 12),
    ("PHASE", "firmware/engines/src/eng_phase.c", "PHASE_PRESETS", 2),
    ("LOFI", "firmware/engines/src/eng_lofi.c", "LOFI_PRESETS", 3),
    ("SAMPLE", None, ["PIANO", "FLUTE", "SAX"], 4),   # (SMP_PRESET_TABLE: the 2nd PIANO is an alias)
    ("VOICE", "firmware/src/eng_formant.c", "FORMANT_PRESETS", 5),
    ("TRIO", "firmware/engines/src/eng_trio.c", "TRIO_PRESETS", 6),
    ("GLCH", "firmware/src/eng_glitch.c", "GLITCH_PRESETS", 7),
    ("GRAIN", "firmware/src/eng_grain.c", "GRAIN_PRESETS", 8),
    ("PHYS", "firmware/src/eng_phys.c", "PHYS_PRESETS", 9),
    ("DRUM", "firmware/src/eng_drum.c", "DRUM_PRESETS", 10),
    ("NOISE", "firmware/engines/src/eng_noise.c", "NOISE_PRESETS", 11),
    ("SLICE", "firmware/src/eng_slice.c", "SLICE_PRESETS", 13),
]
CAT = {"B": "BASS", "L": "LEAD", "P": "PAD", "U": "PLUCK", "K": "KEYS", "D": "DRUM", "F": "FX", "O": "OTHER"}
CAT_RU = {"BASS": "бас", "LEAD": "лид", "PAD": "пэд", "PLUCK": "щипок", "KEYS": "клавиши", "DRUM": "драмы",
          "FX": "шум и FX", "OTHER": "другое"}


def preset_names(src, table):
    s = (ROOT / src).read_text(encoding="utf-8")
    m = re.search(r"preset_t " + table + r"\[\] = \{\n(.*?)\n\};", s, re.S)
    if not m:
        raise SystemExit(f"{src}: no {table}")
    body = re.sub(r"/\*.*?\*/", "", m.group(1), flags=re.S)
    names = re.findall(r'^\s*\{"([^"]+)"', body, re.M)
    return names


def categories():
    s = (ROOT / "firmware/src/category.c").read_text(encoding="utf-8")
    block = s[s.index("PRESET_CAT[16] = {"):]
    block = block[:block.index("};")]
    rows = []
    for line in block.split("\n")[1:]:
        line = re.sub(r"/\*.*?(\*/|$)", "", line)
        parts = re.findall(r'"([^"]*)"', line)
        if parts or line.strip().startswith('""'):
            rows.append("".join(parts))
    return rows


def sound_list(lang):
    cats = categories()
    out, total = [], 0
    for name, src, table, idx in ENGINES:
        names = table if src is None else preset_names(src, table)
        letters = cats[idx] if idx < len(cats) else ""
        if src is None:
            letters = letters[:1] + letters[2:]
        items = []
        for k, n in enumerate(names):
            c = CAT.get(letters[k], "") if k < len(letters) else ""
            items.append(f"{n}" + (f" <small>({CAT_RU[c] if lang == 'ru' else c.lower()})</small>" if c else ""))
        total += len(names)
        out.append(f"<h3>{name} · {len(names)}</h3>\n<p>" + ", ".join(items) + "</p>")
    head = (f"<p>{total} звуков. В скобках категория для фильтра LIST на SAVE &gt; PRESETS (K4).</p>" if lang == "ru"
            else f"<p>{total} sounds. In brackets: the category for LIST on SAVE &gt; PRESETS (K4).</p>")
    return head + "\n" + "\n".join(out), total


def source_tarball(dst, version):
    """the source of this build: the files git tracks, as they are in the tree (nothing local or untracked: build
    output, notes, editor files); a new file goes in once it is added to git"""
    name = f"kriechstrom-{version}-src"
    path = dst / f"{name}.tar.gz"
    files = subprocess.run(["git", "-C", str(ROOT), "ls-files", "-z"], check=True,
                           capture_output=True).stdout.decode().split("\0")
    with tarfile.open(path, "w:gz") as tar:
        for f in sorted(x for x in files if x):
            if (ROOT / f).is_file() and not f.endswith(".fwsc"):
                tar.add(ROOT / f, arcname=f"{name}/{f}", recursive=False)
    return path


def main(pkg, version, out):
    pkg, out = Path(pkg), Path(out)
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    subprocess.run([sys.executable, str(ROOT / "web" / "make_site.py"), str(pkg), version, str(out)], check=True)
    fws = sorted((out / "firmware").glob("*.fwsc"))
    if len(fws) != 1:
        raise SystemExit(f"firmware/: {len(fws)} packages")
    fwsc = fws[0].name
    (out / "src").mkdir()
    tb = source_tarball(out / "src", version)
    size = f"{tb.stat().st_size / 1e6:.1f} MB"
    used = set()
    sounds = set()
    total = 0
    for rel in ("index.html", "ru.html", "style.css", "manual/en.html", "manual/ru.html"):
        s = (SITE / rel).read_text(encoding="utf-8")
        if "<!--SOUNDS-->" in s:
            lst, total = sound_list("ru" if rel.endswith("ru.html") else "en")
            s = s.replace("<!--SOUNDS-->", lst)
        used |= set(re.findall(r'shots/([a-z0-9_]+\.png)', s))
        sounds |= set(re.findall(r'audio/([a-z0-9_]+\.m4a)', s))
        (out / rel).parent.mkdir(parents=True, exist_ok=True)
        (out / rel).write_text(s, encoding="utf-8")
    if not total:
        total = sound_list("en")[1]
    nglch = next(len(preset_names(src, table)) for name, src, table, idx in ENGINES if name == "GLCH")
    for rel in ("index.html", "ru.html", "manual/en.html", "manual/ru.html"):
        p = out / rel
        s = p.read_text(encoding="utf-8")
        s = (s.replace("@FWSC@", fwsc).replace("@SRC@", tb.name).replace("@SRCSIZE@", size)
             .replace("@VERSION@", version).replace("@NSOUNDS@", str(total)).replace("@NGLCH@", str(nglch)))
        p.write_text(s, encoding="utf-8")
    shutil.copytree(SITE / "art", out / "art", ignore=shutil.ignore_patterns("splash_preview.png"))   # (tools/krst_art.py)
    (out / "shots").mkdir()
    for n in sorted(used):
        if not (SHOTS / n).exists():
            raise SystemExit(f"shots/{n}: not rendered (run tests/run_tests.sh first)")
        shutil.copy(SHOTS / n, out / "shots" / n)
    if sounds:
        (out / "audio").mkdir()
    for n in sorted(sounds):
        if not (DEMOS / n).exists():
            raise SystemExit(f"audio/{n}: not rendered (run tools/krst_demos.sh first)")
        shutil.copy(DEMOS / n, out / "audio" / n)
    words = sorted((ROOT / "web" / "words").glob("*.json"))
    (out / "words").mkdir()
    for w in words:
        shutil.copy(w, out / "words" / w.name)
    link = (ROOT / "build" / "gen" / "ann_words.h")
    if link.exists():
        m = re.search(r'words/([0-9a-f]+\.json)', link.read_text())
        if m and not (out / "words" / m.group(1)).exists():
            raise SystemExit(f"words/{m.group(1)}: the build links to it, web/words has not got it")
    print(f"site: {out} ({fwsc}, {len(used)} screens, {len(sounds)} demos, {total} sounds, {len(words)} words files, "
          f"source {size})")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    main(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else ROOT / "build" / "site")
